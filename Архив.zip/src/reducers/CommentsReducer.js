import {COMMENTS_FETCH_SUCCESS, COMMENT_CHANGED} from '../actions/types'

const INITIAL_STATE = {
  comment: null,
  error: '',
  loading: false
};

export default(state = INITIAL_STATE, action) => {
  switch (action.type) {
    case COMMENT_CHANGED:
      return {
        ...state,
        comment: action.payload
      };
    case COMMENTS_FETCH_SUCCESS:
      return {
        ...state,
        ...INITIAL_STATE,
        user: action.payload
      };
    default:
      return state;
  }
}
