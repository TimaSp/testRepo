import {combineReducers} from 'redux';
import AuthReducer from './AuthReducer'
import GuideReducer from './GuidesReducer'
import EventsReducer from './EventsReducer'
import CommentsReducer from './CommentsReducer'

export default combineReducers({
   auth: AuthReducer,
   guide: GuideReducer,
   event: EventsReducer,
   comm: CommentsReducer
});
