import wilddog from 'wilddog';
import {Actions} from 'react-native-router-flux';

import {COMMENTS_FETCH_SUCCESS, COMMENT_CHANGED} from './types'

export const commentChanged = (text) => {
  console.log(text)
  return {type: COMMENT_CHANGED, payload: text}
}

export const submitComment = ({comment, uid}) => {
  return (dispatch) => {
    dispatch({type: COMMENTS_FETCH_SUCCESS});
    alert('Sended')
    const ref = wilddog.sync().ref().child('events').child(uid).child('comments');
    const user = wilddog.auth().currentUser;
    ref.push({like: 0, content: comment, userUid: user.uid, time: Date.now()})
  };
}

const commentSendedSuccess = (dispatch, comment) => {
  dispatch({type: LOGIN_USER_SUCCESS, payload: user})
  Actions.root();
}
