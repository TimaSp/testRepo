import React, {Component} from 'react';
import {Scene, Router, Actions} from 'react-native-router-flux';
import {Image, View} from 'react-native';
import Moment from 'moment';
import {
  Container,
  Content,
  Button,
  Icon,
  Text,
  Card,
  CardItem,
  Right
} from 'native-base';

class EventSingle extends Component {

  onRowPress() {
    Actions.taxiModal({event: this.props.event})
  }
  onSpecialPress() {
    Actions.specialModal({event: this.props.event})
  }
  onLikePress() {
    Actions.like({event: this.props.event})
  }
  onCommentsPress() {
    Actions.come({event: this.props.event})
  }
  onFavoritePress() {
    Actions.fave({event: this.props.event})
  }
  render() {
    const {
      title,
      poster,
      address,
      description,
      time,
      date,
      like,
      comments,
      users_fav
    } = this.props.event;

    if (comments !== undefined) {
      var hmcomment = Object.values(comments).length
    } else {
       var hmcomment = 0
    }
    if (users_fav != undefined) {
      var hmfav = Object.values(users_fav).length
    } else {
      var hmfav = 0
    }
    return (
      <Container>
        <Content>
          <Image style={{
            width: 365,
            height: 200
          }} source={{
            uri: poster + '?imageslim'
          }}/>
          <Card>
            <CardItem>
              <Button transparent onPress={this.onLikePress.bind(this)}>
                <Icon active name="beer"/>
                <Text>{like}</Text>
              </Button>
              <Button transparent onPress={this.onCommentsPress.bind(this)}>
                <Icon active name="chatbubbles"/>
                <Text>{hmcomment}</Text>
              </Button>
              <Button transparent onPress={this.onFavoritePress.bind(this)}>
                <Icon active name="heart"/>
                <Text>{hmfav}</Text>
              </Button>
            </CardItem>
          </Card>
          <Card>
            <CardItem>
              <Icon active name="navigate"/>
              <Text>{address}</Text>
              <Right>
                <Icon name="arrow-forward"/>
              </Right>
            </CardItem>
            <CardItem onPress={this.onRowPress.bind(this)}>
              <Icon active name="car" onPress={this.onRowPress.bind(this)}/>
              <Text onPress={this.onRowPress.bind(this)}>Taxi Info</Text>
              <Right >
                <Icon name="arrow-forward" onPress={this.onRowPress.bind(this)}/>
              </Right>
            </CardItem>
            <CardItem onPress={this.onSpecialPress.bind(this)}>
              <Icon onPress={this.onSpecialPress.bind(this)} active name="pulse"/>
              <Text onPress={this.onSpecialPress.bind(this)}>Special Offer</Text>
              <Right onPress={this.onSpecialPress.bind(this)}>
                <Icon name="arrow-forward" onPress={this.onSpecialPress.bind(this)}/>
              </Right>
            </CardItem>
            <CardItem>
              <Icon active name="time"/>
              <Text>{time}</Text>
            </CardItem>
            <CardItem>
              <Icon active name="calendar"/>
              <Text>{Moment(date).format('d MMM')}
              </Text>
            </CardItem>
            <CardItem>
              <Text>{description}</Text>
            </CardItem>
          </Card>

        </Content>
      </Container>
    );
  }
}

export default EventSingle;
