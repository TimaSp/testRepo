import { AppRegistry } from 'react-native';

import App from './src/app';


AppRegistry.registerComponent('HanAPp', () => App);
